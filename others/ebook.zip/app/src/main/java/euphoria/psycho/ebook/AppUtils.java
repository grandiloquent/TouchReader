package euphoria.psycho.ebook;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class AppUtils {

    private static Context sContext;

    public static void setContext(Context context) {
        sContext = context;
    }

    public static SharedPreferences getDefaultSharedPreferences() {
        return PreferenceManager.getDefaultSharedPreferences(sContext);
    }

    public static void setClipboardText(String value) {
        final ClipboardManager clipboardManager = (ClipboardManager) sContext.getSystemService(Context.CLIPBOARD_SERVICE);
        clipboardManager.setPrimaryClip(ClipData.newPlainText("", value));

    }
}
