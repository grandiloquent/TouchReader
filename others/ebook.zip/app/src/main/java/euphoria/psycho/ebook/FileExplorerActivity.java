package euphoria.psycho.ebook;

import android.app.Activity;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.view.*;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import euphoria.psycho.ebook.mobi.MobiAdapter;
import euphoria.psycho.ebook.mobi.PDBReader;
import euphoria.psycho.ebook.mobi.PalmDataBase;
import euphoria.psycho.ebook.repositories.Files;

import java.io.*;
import java.nio.charset.Charset;
import java.text.Collator;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileExplorerActivity extends Activity {
    private ListView mListView;
    private List<String> mFileList;
    private FileItemAdapter mFileItemAdapter;
    private String mCurrentDirectory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prepare();
    }

    public static List<String> getFiles(String dir) {
        List<String> ls = new ArrayList<>();

        File dirFile = new File(dir);
        if (!dirFile.isDirectory())
            return ls;
        File[] files = dirFile.listFiles();
        final Collator collator = Collator.getInstance(Locale.CHINA);

        Arrays.sort(files, new Comparator<File>() {
            @Override
            public int compare(File f1, File f2) {
                if ((f1.isDirectory() && f2.isDirectory()) || (f1.isFile() && f2.isFile())) {
                    return collator.compare(f1.getName(), f2.getName());
                }
                if (f1.isDirectory() && f2.isFile()) {
                    return -1;
                }
                if (f2.isDirectory() && f1.isFile()) {
                    return 1;
                }
                return 0;
            }
        });
        for (File file : files) {
            ls.add(file.getName());
        }
        return ls;
    }

    private void prepare() {
        setContentView(R.layout.activity_file_explorer);
        mCurrentDirectory = AppUtils.getDefaultSharedPreferences().getString("current_directory", Environment.getExternalStorageDirectory().getAbsolutePath());
        mListView = findViewById(R.id.listView);
        registerForContextMenu(mListView);
        mFileList = getFiles(mCurrentDirectory);

        mFileItemAdapter = new FileItemAdapter();
        mListView.setAdapter(mFileItemAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                File file = new File(mCurrentDirectory, mFileList.get(i));
                if (file.isDirectory()) {
                    RefreshList(file.getAbsolutePath());
                }
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.file_explorer_context, menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }


    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int index = info.position;
        int action = item.getItemId();
        switch (action) {
            case R.id.action_combine:
                File dir = new File(mCurrentDirectory, mFileList.get(index));
                FileUtils.fileCombineInDirectories(dir.getAbsolutePath());
                return true;
            case R.id.action_import:
                File file = new File(mCurrentDirectory, mFileList.get(index));
                if (file.isFile() && file.getName().endsWith(".txt")) {
                    ArticleProvider.getInstance(this).importDocument(file);
                }
                RefreshList(mCurrentDirectory);

                break;
            case R.id.action_import_directory:
                file = new File(mCurrentDirectory, mFileList.get(index));
                if (file.isFile()) {
                    file = file.getParentFile();

                    File[] files = file.listFiles(new FileFilter() {
                        @Override
                        public boolean accept(File fc) {
                            if (fc.isFile() && fc.getName().endsWith(".txt")) return true;
                            return false;
                        }
                    });
                    for (File f : files) {
                        ArticleProvider.getInstance(this).importDocument(f);

                    }
                }
                RefreshList(mCurrentDirectory);

                break;
            case R.id.action_setFontface:
                file = new File(mCurrentDirectory, mFileList.get(index));
                if (file.isFile() && file.getName().endsWith(".ttf")) {
                    AppUtils.getDefaultSharedPreferences().edit().putString("typeface", file.getAbsolutePath()).commit();
                }
                break;
            case R.id.action_convert_to_txt:
                file = new File(mCurrentDirectory, mFileList.get(index));
                convertToTextFile(file);
                RefreshList(mCurrentDirectory);

                break;
            case R.id.action_convert_to_txt_directory:
                file = new File(mCurrentDirectory, mFileList.get(index));
                if (file.isFile()) {
                    convertToTextFileInDirectory(file.getParentFile());
                    RefreshList(mCurrentDirectory);

                }

                break;
            case R.id.action_delete_file:
                file = new File(mCurrentDirectory, mFileList.get(index));
                if (file.isFile()) {
                    file.delete();
                    RefreshList(mCurrentDirectory);
                }
                break;

        }

        return super.onContextItemSelected(item);
    }

    private void convertToTextFileInDirectory(File dir) {

        File[] files = dir.listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                if (file.isFile()) return true;
                return false;
            }
        });

        for (File file : files) {
            try {
                convertToTextFile(file);
            } catch (Exception e) {

            }
        }
    }

    private void convertToTextFile(File value) {

        if (Pattern.compile("\\.(?:mobi|azw3|prc)$").matcher(value.getName()).find()) {
            convertMobiToTextFile(value);
        } else if (value.getName().endsWith(".pdf")) {
            String content = EbookUtils.pdf2txt(value.getAbsolutePath());
            String targetFileName = EbookUtils.changeExtension(value.getAbsolutePath(), ".txt");
            EbookUtils.writeFile(targetFileName, content.replaceAll("\\-\\s+", ""));
        } else if (value.getName().endsWith(".epub")) {
            EbookUtils.epub2txt(value.getAbsolutePath());
        }
    }

    private void convertMobiToTextFile(File value) {


        PDBReader reader = new PDBReader();
        PalmDataBase pdb = null;
        try {
            pdb = reader.read(value);
        } catch (IOException e) {
            e.printStackTrace();
        }
        MobiAdapter adapter = new MobiAdapter(pdb);
        String tableContents = adapter.getTextContents();

        String converted = tableContents.replaceAll("(</p>)|(</*br>)", "\n\n");

        converted = converted.replaceAll("<[^>]*>", "");


        writeConvertFile(value, converted);

    }

    private void writeConvertFile(File file, String value) {

        String targetFileName = Files.changeExtension(file.getAbsolutePath(), "txt");

        try {
            Files.writeStringToFile(targetFileName, value);
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private void RefreshList(String directory) {
        List<String> ls = getFiles(directory);
        mFileItemAdapter.switchData(ls);
        mCurrentDirectory = directory;
    }

    private class ViewHolder {
        public TextView title;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.file_explorer, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onPause() {
        AppUtils.getDefaultSharedPreferences().edit().putString("current_directory", mCurrentDirectory).commit();
        super.onPause();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int action = item.getItemId();
        switch (action) {
            case R.id.action_exit:
                this.finish();
                return true;
            case R.id.action_import_from_clipboard:
                ClipboardManager clipboardManager = (ClipboardManager) this.getSystemService(CLIPBOARD_SERVICE);
                if (clipboardManager.hasPrimaryClip()) {

                    String value = clipboardManager.getPrimaryClip().getItemAt(0).getText().toString();
                    if (!TextUtils.isEmpty(value))
                        ArticleProvider.getInstance(this).insertArticle(value.trim());
                }
                break;
            case R.id.action_rename_opera:
                renameOpera();
                break;
            case R.id.action_rename_pdf:
                EbookUtils.renamPDFInDirectory(mCurrentDirectory);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void renameOpera() {
        File currentDirectory = new File(mCurrentDirectory);

        File[] files = currentDirectory.listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                if (file.isFile() && file.getName().endsWith(".mhtml"))
                    return true;
                return false;
            }
        });

        File targetDirectory = new File(mCurrentDirectory, "Files");
        targetDirectory.mkdirs();

        for (File file : files) {
            try {

                FileInputStream fstream = new FileInputStream(file);
                BufferedReader br = new BufferedReader(new InputStreamReader(fstream, Charset.forName("utf-8")));

                String strLine;
                StringBuilder value = new StringBuilder();
                boolean continueString = false;
                while ((strLine = br.readLine()) != null) {
                    if (strLine.startsWith("Subject:")) {
                        if (strLine.endsWith("Question")) {
                            continueString = true;
                        } else {
                            String fileName = strLine.substring("Subject:".length() + 1).replaceAll("[\\\\/:*?\"<>|]", " ");
                            file.renameTo(new File(targetDirectory, fileName + ".mhtml"));
                            break;
                        }

                    }
                    if (continueString) {
                        value.append(strLine).append("\n");
                    }
                }
                if (continueString) {
                    Matcher matcher = Pattern.compile("rendered_qtext\">([^<]*)<").matcher(value.toString());
                    if (matcher.find()) {
                        String fileName = matcher.group(1);

                        File tf = new File(targetDirectory, "Quora");
                        tf.mkdirs();
                        file.renameTo(new File(tf, fileName.replaceAll("[\\\\/:*?\"<>|]", " ") + ".mhtml"));
                    }

                }

                br.close();

            } catch (Exception e) {
                Log.e("TAG", e.getMessage());
            }
        }
    }

    @Override
    public void onBackPressed() {
        File file = new File(mCurrentDirectory);
        file = file.getParentFile();
        if (file.isDirectory()) {
            RefreshList(file.getAbsolutePath());
        } else
            super.onBackPressed();
    }

    private class FileItemAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return mFileList.size();
        }

        public void switchData(List<String> ls) {
            mFileList.clear();
            mFileList.addAll(ls);
            notifyDataSetChanged();
        }

        @Override
        public String getItem(int i) {
            return mFileList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ViewHolder viewHolder;
            if (view == null) {
                view = LayoutInflater.from(FileExplorerActivity.this).inflate(R.layout.list_item, viewGroup, false);
                viewHolder = new ViewHolder();
                viewHolder.title = view.findViewById(R.id.title);
                view.setTag(viewHolder);
            } else {

                viewHolder = (ViewHolder) view.getTag();
            }
            viewHolder.title.setText(mFileList.get(i));
            return view;
        }
    }
}
