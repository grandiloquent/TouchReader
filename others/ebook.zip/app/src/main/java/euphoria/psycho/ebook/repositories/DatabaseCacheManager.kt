package euphoria.psycho.ebook.repositories

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Environment
import java.io.File
import java.util.*


class DatabaseCacheManager(context: Context) : SQLiteOpenHelper(context, File(File(Environment.getExternalStorageDirectory(), ".readings"), "cache.db").absolutePath, null, 1) {

    fun insert(pattern: String, tag: String, anchors: List<String>) {

        val values = ContentValues()
        values.put("pattern", pattern)
        values.put("tag", tag)
        values.put("content", StringHelper.listToString(anchors, ','))
        writableDatabase.insert("caches", null, values)
    }

    fun getAnchors(pattern: String, tag: String): List<String>? {
        val cursor = readableDatabase.rawQuery("SELECT content from caches WHERE pattern=? AND tag=?", arrayOf(pattern, tag))

        if (cursor.moveToNext()) {
            val value = cursor.getString(0)
            cursor.close()
            return Arrays.asList(*value.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray())
        }
        return null
    }

    override fun onCreate(sqLiteDatabase: SQLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS caches (pattern TEXT,tag TEXT ,content TEXT)")
    }

    override fun onUpgrade(sqLiteDatabase: SQLiteDatabase, i: Int, i1: Int) {

    }

    companion object {

        var instance: DatabaseCacheManager? = null
            private set

        fun initializeInstance(context: Context): DatabaseCacheManager {
            if (instance == null) {
                instance = DatabaseCacheManager(context)
            }
            return instance!!
        }
    }
}