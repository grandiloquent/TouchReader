//package euphoria.psycho.ebook;
//
//import android.content.Context;
//import android.graphics.PointF;
//import android.view.MotionEvent;
//import android.view.View;
//
//public abstract class BaseReadView extends View {
//    private int dx, dy;
//    private long et = 0;
//    private boolean cancel = false;
//    private boolean center = false;
//    protected PointF mTouch = new PointF();
//    protected float actiondownX, actiondownY;
//    protected float touch_down = 0;
//    protected int mScreenWidth;
//    protected int mScreenHeight;
//    protected OnReadStateChangeListener listener;
//    protected abstract void calcCornerXY(float x, float y);
//
//    public BaseReadView(Context context) {
//        super(context);
//    }
//    protected void resetTouchPoint() {
//        mTouch.x = 0.1f;
//        mTouch.y = 0.1f;
//        touch_down = 0;
//        calcCornerXY(mTouch.x, mTouch.y);
//    }
//    @Override
//    public boolean onTouchEvent(MotionEvent e) {
//        switch (e.getAction()) {
//            case MotionEvent.ACTION_DOWN:
//                et = System.currentTimeMillis();
//                dx = (int) e.getX();
//                dy = (int) e.getY();
//                mTouch.x = dx;
//                mTouch.y = dy;
//                actiondownX = dx;
//                actiondownY = dy;
//                touch_down = 0;
//                pagefactory.onDraw(mCurrentPageCanvas);
//                if (actiondownX >= mScreenWidth / 3 && actiondownX <= mScreenWidth * 2 / 3
//                        && actiondownY >= mScreenHeight / 3 && actiondownY <= mScreenHeight * 2 / 3) {
//                    center = true;
//                } else {
//                    center = false;
//                    calcCornerXY(actiondownX, actiondownY);
//                    if (actiondownX < mScreenWidth / 2) {// 从左翻
//                        BookStatus status = pagefactory.prePage();
//                        if (status == BookStatus.NO_PRE_PAGE) {
//                            ToastUtils.showSingleToast("没有上一页啦");
//                            return false;
//                        } else if (status == BookStatus.LOAD_SUCCESS) {
//                            abortAnimation();
//                            pagefactory.onDraw(mNextPageCanvas);
//                        } else {
//                            return false;
//                        }
//                    } else if (actiondownX >= mScreenWidth / 2) {// 从右翻
//                        BookStatus status = pagefactory.nextPage();
//                        if (status == BookStatus.NO_NEXT_PAGE) {
//                            ToastUtils.showSingleToast("没有下一页啦");
//                            return false;
//                        } else if (status == BookStatus.LOAD_SUCCESS) {
//                            abortAnimation();
//                            pagefactory.onDraw(mNextPageCanvas);
//                        } else {
//                            return false;
//                        }
//                    }
//                    listener.onFlip();
//                    setBitmaps(mCurPageBitmap, mNextPageBitmap);
//                }
//                break;
//            case MotionEvent.ACTION_MOVE:
//                if (center)
//                    break;
//                int mx = (int) e.getX();
//                int my = (int) e.getY();
//                cancel = (actiondownX < mScreenWidth / 2 && mx < mTouch.x) || (actiondownX > mScreenWidth / 2 && mx > mTouch.x);
//                mTouch.x = mx;
//                mTouch.y = my;
//                touch_down = mTouch.x - actiondownX;
//                this.postInvalidate();
//                break;
//            case MotionEvent.ACTION_UP:
//            case MotionEvent.ACTION_CANCEL:
//
//                long t = System.currentTimeMillis();
//                int ux = (int) e.getX();
//                int uy = (int) e.getY();
//
//                if (center) { // ACTION_DOWN的位置在中间，则不响应滑动事件
//                    resetTouchPoint();
//                    if (Math.abs(ux - actiondownX) < 5 && Math.abs(uy - actiondownY) < 5) {
//                        listener.onCenterClick();
//                        return false;
//                    }
//                    break;
//                }
//
//                if ((Math.abs(ux - dx) < 10) && (Math.abs(uy - dy) < 10)) {
//                    if ((t - et < 1000)) { // 单击
//
//                    } else { // 长按
//                        pagefactory.cancelPage();
//                        restoreAnimation();
//                    }
//                    postInvalidate();
//                    return true;
//                }
//                if (cancel) {
//                    pagefactory.cancelPage();
//                    restoreAnimation();
//                    postInvalidate();
//                } else {
//                    startAnimation();
//                    postInvalidate();
//                }
//                cancel = false;
//                center = false;
//                break;
//            default:
//                break;
//        }
//        return true;
//    }
//
//}