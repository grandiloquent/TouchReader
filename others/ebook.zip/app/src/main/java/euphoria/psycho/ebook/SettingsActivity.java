package euphoria.psycho.ebook;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.EditText;

public class SettingsActivity extends Activity {
    private EditText pFontSize;
    private EditText pLineSpacingMultiplier;
    private EditText pExplainfontsize;
    private EditText pPadding;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_preferences);

        prepare();
    }

    private void prepare() {
        pFontSize = findViewById(R.id.p_fontsize);
        pLineSpacingMultiplier = findViewById(R.id.p_lineSpacingMultiplier);
        pExplainfontsize = findViewById(R.id.p_explainfontsize);

        pPadding = findViewById(R.id.p_padding);

        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);

        float fontsize = preferences.getFloat("fontsize", 0F);

        if (fontsize > 0)
            pFontSize.setText(Float.toString(fontsize));


        float explainfontsize = preferences.getFloat("explainfontsize", 0F);
        if (explainfontsize > 0) {
            pExplainfontsize.setText(Float.toString(explainfontsize));
        }
        float lineSpacingMultiplier = preferences.getFloat("lineSpacingMultiplier", 0F);

        if (lineSpacingMultiplier > 0) {
            pLineSpacingMultiplier.setText(Float.toString(lineSpacingMultiplier));
        }
        int padding = preferences.getInt("padding", 0);

        if (padding > 0) {
            pPadding.setText(Float.toString(padding));
        }
    }

    @Override
    public void finish() {
        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);

        if (pFontSize.getText().length() > 0) {
            float fontsize = Float.parseFloat(pFontSize.getText().toString());
            if (fontsize > 0) {
                preferences.edit().putFloat("fontsize", fontsize).commit();
            }
        }

        if (pExplainfontsize.getText().length() > 0) {
            float explainfontsize = Float.parseFloat(pExplainfontsize.getText().toString());

            if (explainfontsize > 0) {
                preferences.edit().putFloat("explainfontsize", explainfontsize).commit();
            }
        }
        if (pLineSpacingMultiplier.getText().length() > 0) {
            float lineSpacingMultiplier = Float.parseFloat(pLineSpacingMultiplier.getText().toString());
            if (lineSpacingMultiplier > 0) {
                preferences.edit().putFloat("lineSpacingMultiplier", lineSpacingMultiplier).commit();
            }
        }
        if (pPadding.getText().length() > 0) {
            int padding = 0;

            try {
                padding = Integer.parseInt(pPadding.getText().toString());
            } catch (Exception e) {
                padding = (int) Float.parseFloat(pPadding.getText().toString());

            }

            if (padding > 0) {
                preferences.edit().putInt("padding", padding).commit();
            }
        }
        setResult(RESULT_OK, new Intent());
        super.finish();
    }
}