package euphoria.psycho.ebook.repositories

import android.widget.ScrollView
import android.widget.TextView

object ViewHelper {

    val ID_EXIST = 11
    val ID_EXIST_LABEL = "退出"

    fun bringPointIntoView(textView: TextView,
                           scrollView: ScrollView, offset: Int) {
        val line = textView.layout.getLineForOffset(offset)
        val y = ((line + 0.5) * textView.lineHeight).toInt()
        scrollView.smoothScrollTo(0, y - scrollView.height / 2)
    }
}
