package euphoria.psycho.ebook;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import euphoria.psycho.ebook.repositories.BasePopupWindow;

public class SettingPopupWindow extends BasePopupWindow {
    public interface Listener {

        void switchDictionary();

        void switchSelectable();

        void increaseFontSize();

        void decreaseFontSize();

        void openSettings();

        void jump();

        void openFileBrowser();

        void openTableContents();

        void searchInDocument();

        void searchInCurrent();

        void openAnnotations();

        void searchInDocumentString();
    }

    private Listener mListener;

    public void setListener(Listener listener) {
        mListener = listener;
    }

    @Override
    protected View createConvertView() {
        return LayoutInflater.from(mContext)
                .inflate(R.layout.menu_popup_bottom, null);
    }


    @Override
    protected void setSize(int width, int height) {
        setWidth((int) (width * 0.95));
        setHeight((int) (height * 0.45));
    }

    public SettingPopupWindow(Context context) {
        super(context);

        mConvertView.findViewById(R.id.btn_switch_dictionary).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.switchDictionary();
                dismiss();

            }
        });
        mConvertView.findViewById(R.id.btn_switch_selectable).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.switchSelectable();
                dismiss();
            }
        });
        mConvertView.findViewById(R.id.btn_increase_font_size).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.increaseFontSize();
                dismiss();
            }
        });
        mConvertView.findViewById(R.id.btn_decrease_font_size).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.decreaseFontSize();
                dismiss();
            }
        });
        mConvertView.findViewById(R.id.btn_open_settings).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.openSettings();
                dismiss();
            }
        });
        mConvertView.findViewById(R.id.btn_jump).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.jump();
                dismiss();
            }
        });
        mConvertView.findViewById(R.id.btn_open_file_browser).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.openFileBrowser();
                dismiss();
            }
        });
        mConvertView.findViewById(R.id.btn_open_table_contents).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.openTableContents();
                dismiss();
            }
        });
        mConvertView.findViewById(R.id.btn_search_in_current).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.searchInCurrent();
                dismiss();
            }
        });
        mConvertView.findViewById(R.id.btn_search_in_document).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.searchInDocument();
                dismiss();
            }
        });
        mConvertView.findViewById(R.id.btn_open_annotations).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.openAnnotations();
                dismiss();
            }
        });
        mConvertView.findViewById(R.id.btn_search_string).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) mListener.searchInDocumentString();
                dismiss();
            }
        });
    }
}
