package euphoria.psycho.ebook;

import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

public class ClipboardService extends Service {
    private ClipboardManager mClipboardManager;

    private ClipboardManager.OnPrimaryClipChangedListener mOnPrimaryClipChangedListener;

    private String mLastedString="";

    @Override
    public void onCreate() {
        super.onCreate();


        mOnPrimaryClipChangedListener = new ClipboardManager.OnPrimaryClipChangedListener() {
            @Override
            public void onPrimaryClipChanged() {

                ClipData clipData = mClipboardManager.getPrimaryClip();
                if (clipData != null && clipData.getItemCount() > 0) {
                    CharSequence c = clipData.getItemAt(0).getText();
                    if (c != null && !mLastedString.equals(c.toString())) {
                        ArticleProvider.getInstance(ClipboardService.this).insertArticle(c.toString().replaceAll("\\-\\s+", ""));
                        mLastedString = c.toString();
                    }
                }
            }
        };
        mClipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        mClipboardManager.addPrimaryClipChangedListener(mOnPrimaryClipChangedListener);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

}
