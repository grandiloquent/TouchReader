package euphoria.psycho.ebook.repositories

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.widget.EditText

object Views {


    interface Listener {
        fun ok(value: String)
    }

    fun openDialog(content: Context, title: String, defaultValue: String?, listener: Listener?) {
        val editText = EditText(content)

        if (!defaultValue.isNullOrEmpty())
            editText.setText(defaultValue)
        val builder = AlertDialog.Builder(content)
                .setView(editText)
                .setTitle(title)
                .setPositiveButton("确定", DialogInterface.OnClickListener { dialog, i ->
                    run {
                        listener?.ok(editText.text.toString())
                    }
                }).setNegativeButton("取消", DialogInterface.OnClickListener { dialog, i ->
            run {
                dialog.dismiss()
            }
        });

        builder.show()
    }
}