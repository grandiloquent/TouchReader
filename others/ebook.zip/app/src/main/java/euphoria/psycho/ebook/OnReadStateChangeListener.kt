package euphoria.psycho.ebook

interface OnReadStateChangeListener {

    fun onChapterChanged(chapter: Int)

    fun onPageChanged(chapter: Int, page: Int)

    fun onLoadChapterFailure(chapter: Int)

    fun onCenterClick()

    fun onFlip()
}