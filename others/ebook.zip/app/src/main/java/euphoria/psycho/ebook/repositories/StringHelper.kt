package euphoria.psycho.ebook.repositories

import java.util.ArrayList

object StringHelper {

    fun <T> listToString(floats: List<T>, separator: Char): String {
        val builder = StringBuilder()

        for (i in floats.indices) {
            builder.append(floats[i]).append(separator)
        }
        return builder.toString()
    }

    fun intsToString(floats: List<Int>, separator: Char): String {
        val builder = StringBuilder()

        for (i in floats.indices) {
            builder.append(floats[i]).append(separator)
        }
        return builder.toString()
    }


    fun stringToFloats(value: String, separator: Char): List<Float>? {
        val strings = value.split(Character.toString(separator).toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        if (strings == null || strings.size < 1) return null
        val floats = ArrayList<Float>()
        for (i in strings.indices) {
            floats.add(java.lang.Float.parseFloat(strings[i]))
        }
        return floats
    }

}
