package euphoria.psycho.ebook;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import euphoria.psycho.ebook.repositories.Views;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.Charset;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DocumentsActivity extends Activity {
    private FileItemAdapter mFileItemAdapter;
    private List<String> mList;
    private ListView mListView;

    private void changeTag(final String defaultValue) {
        Views.INSTANCE.openDialog(this, "更改文章标签", defaultValue, new Views.Listener() {
            @Override
            public void ok(@NotNull String value) {

                if (value.trim().length() > 0)
                    ArticleProvider.getInstance(DocumentsActivity.this).updateTag(defaultValue, value.trim());
                refreshList();
            }


        });
    }

    private void addNewDocument() {
        EditText editText = new EditText(this);
        AlertDialog.Builder builder = new AlertDialog.Builder(this)

                .setView(editText)
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                })
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        dialogInterface.dismiss();
                    }
                });

        builder.show();
    }

    private static void combineFiles(String dir) {

    }

    private void refreshList() {
        mFileItemAdapter.switchData(getList());
    }

    private void prepare() {
        setContentView(R.layout.activity_file_explorer);
        mListView = findViewById(R.id.listView);
        registerForContextMenu(mListView);
        mList = getList();
        mFileItemAdapter = new FileItemAdapter();
        mListView.setAdapter(mFileItemAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent();
                intent.putExtra("tag", mList.get(i));
                setResult(Activity.RESULT_OK, intent);
                finish();

            }
        });
    }

    public List<String> getList() {

        return ArticleProvider.getInstance(this).listTag();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prepare();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.list_explorer, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int action = item.getItemId();
        switch (action) {
            case R.id.action_exit:
                this.finish();
                return true;
            case R.id.action_clipboard_add_prefix_items:
                addPrefixClipboard();
                return true;
            case R.id.action_import_from_clipboard:
                ClipboardManager clipboardManager = (ClipboardManager) this.getSystemService(CLIPBOARD_SERVICE);
                if (clipboardManager.hasPrimaryClip()) {
                    CharSequence charSequence = clipboardManager.getPrimaryClip().getItemAt(0).getText();
                    if (charSequence == null) return true;
                    String value = charSequence.toString();
                    if (!TextUtils.isEmpty(value)) {
//                        StringBuilder builder = new StringBuilder();
//                        String[] lines = value.split("\n");
//                        for (String s : lines) {
//                            s = s.trim();
//                            if (s.length() == 0) continue;
//
//                            if (s.endsWith("-")) {
//                                s = s.replaceFirst("\\-$", "");
//                                builder.append(s);
//                            } else {
//                                builder.append(s + " ");
//                            }
//                        }
                        ArticleProvider.getInstance(this).insertArticle(value.replaceAll("\\-\\s+", ""));

                        Toast.makeText(DocumentsActivity.this, "Sucessly.", Toast.LENGTH_SHORT).show();

                    }
                }
                return true;
            case R.id.action_import_kindle:
                File databaseFile = new File(Environment.getExternalStorageDirectory(), "annotations.db");
                if (databaseFile.isFile()) {
                    KindleAnnotation kindleAnnotation = new KindleAnnotation(this);
                    String annotations = kindleAnnotation.export();

                    ArticleProvider.getInstance(this).insertArticle(annotations, false);

                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void addPrefixClipboard() {

        ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

        ClipData clipData = clipboardManager.getPrimaryClip();
        if (clipData != null && clipData.getItemCount() > 0) {
            CharSequence prefix = clipData.getItemAt(0).getText();
            if (prefix != null) {
                ArticleProvider articleProvider = ArticleProvider.getInstance(this);
                Pattern pattern = Pattern.compile("^[0-9]{2} ");
                for (String item : mList) {

                    Matcher matcher = pattern.matcher(item);
                    if (matcher.find())
                        articleProvider.updateTag(item, prefix + "-" + item);

                }
                refreshList();
            }
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.list_explorer_context, menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    private void exportDocument(String tag) {
        String value = ArticleProvider.getInstance(this).exportDocument(tag);

        File dirRoot = new File(Environment.getExternalStorageDirectory(), ".readings");
        File dirParent = new File(dirRoot, ".exports");
        if (!dirParent.exists())
            dirParent.mkdirs();

        try {
            FileOutputStream fileOutputStream = new FileOutputStream(new File(dirParent, tag.replaceAll("[\r\n\t\f?:''\"]+", " ") + ".txt"));
            fileOutputStream.write(value.getBytes(Charset.forName("utf-8")));
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int index = info.position;
        int action = item.getItemId();
        switch (action) {
            case R.id.action_delete:
                ArticleProvider.getInstance(this).deleteByTag(mList.get(index));
                refreshList();

                return true;

            case R.id.action_change_tag:

                changeTag(mList.get(index));
                return true;


            case R.id.action_export_document:
                exportDocument(mList.get(index));
                ArticleProvider.getInstance(this).deleteByTag(mList.get(index));
                refreshList();
                return true;
            case R.id.action_export_documents:
                exportDocuments(mList.get(index));
                return true;
            case R.id.action_add_clipboard:
                addFromClipboard(mList.get(index));
                return true;

        }

        return super.onContextItemSelected(item);
    }

    private void addFromClipboard(String s) {
        ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

        ClipData clipData = clipboardManager.getPrimaryClip();
        if (clipData != null && clipData.getItemCount() > 0) {
            CharSequence prefix = clipData.getItemAt(0).getText();
            if (prefix != null) {
                ArticleProvider.getInstance(this).addFromClipboard(s, prefix.toString());
               // refreshList();
            }
        }
    }

    private void exportDocuments(String tag) {
        String prefix = tag.split("-")[0];
        for (String t : mList) {
            if (t.startsWith(prefix)) {
                exportDocument(t);
                ArticleProvider.getInstance(this).deleteByTag(t);
            }
        }
        refreshList();

    }

    private class ViewHolder {
        public TextView title;
    }

    private class FileItemAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return mList.size();
        }

        @Override
        public String getItem(int i) {
            return mList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ViewHolder viewHolder;
            if (view == null) {
                view = LayoutInflater.from(DocumentsActivity.this).inflate(R.layout.list_item, viewGroup, false);
                viewHolder = new ViewHolder();
                viewHolder.title = view.findViewById(R.id.title);
                view.setTag(viewHolder);
            } else {

                viewHolder = (ViewHolder) view.getTag();
            }
            viewHolder.title.setText(mList.get(i));
            return view;
        }

        public void switchData(List<String> ls) {
            mList.clear();
            mList.addAll(ls);
            notifyDataSetChanged();
        }
    }
}
