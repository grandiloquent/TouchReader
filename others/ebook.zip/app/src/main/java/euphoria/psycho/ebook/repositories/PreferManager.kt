package euphoria.psycho.ebook.repositories

import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import android.util.Pair

class PreferManager(context: Context) {

    private val mSharedPreferences: SharedPreferences

    init {
        mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
    }

    fun putString(key: String, value: String) {
        mSharedPreferences.edit().putString(key, value).commit()
    }

    fun putStrings(pairList: List<Pair<String, String>>) {
        val editor = mSharedPreferences.edit()

        for (i in pairList.indices) {
            editor.putString(pairList[i].first, pairList[i].second)
        }
        editor.commit()
    }

    fun putFloat(key: String, value: Float) {
        mSharedPreferences.edit().putFloat(key, value).commit()
    }

    fun getFloat(key: String): Float {
        return mSharedPreferences.getFloat(key, 0f)
    }

    fun putBoolean(key: String, value: Boolean) {
        mSharedPreferences.edit().putBoolean(key, value).commit()
    }

    fun getString(key: String): String {
        return mSharedPreferences.getString(key, null)
    }

    companion object {

        var instance: PreferManager? = null
            private set

        fun initializeInstance(context: Context): PreferManager {
            if (instance == null) {
                instance = PreferManager(context)
            }
            return instance!!;
        }
    }
}

