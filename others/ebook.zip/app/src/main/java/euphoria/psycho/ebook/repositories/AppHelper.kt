package euphoria.psycho.ebook.repositories

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Environment
import android.preference.PreferenceManager

import java.io.File
import java.io.FileFilter
import java.text.Collator
import java.util.*
import java.util.regex.Pattern

object AppHelper {

    var context: Context? = null


    val defaultSharedPreferences: SharedPreferences
        get() = PreferenceManager.getDefaultSharedPreferences(context)


    fun requestCommonPermissions(activity: Activity): Int {
        val requestPermissionCode = 101
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            activity.requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.WAKE_LOCK)//Manifest.permission.INTERNET
                    , requestPermissionCode)
        }

        return requestPermissionCode
    }

    // \f \u000C
    private val ILLEGAL_CHARACTERS = charArrayOf('/', '\n', '\r', '\t', '\u0000', '\u000C', '`', '?', '*', '\\', '<', '>', '|', '\"', ':')

    fun getValidateWindowFileName(fileName: String, replacer: Char): String {
        var fileName = fileName

        for (c in ILLEGAL_CHARACTERS) {
            fileName = fileName.replace(c, replacer)
        }
        return fileName
    }

    fun getFileExtension(file: File): String {
        val name = file.name
        try {
            return name.substring(name.lastIndexOf(".") + 1)
        } catch (e: Exception) {
            return ""
        }

    }

    fun getExternalStorageDirectory(fileName: String?): File {
        if (fileName == null)
            return Environment.getExternalStorageDirectory()
        else
            return File(Environment.getExternalStorageDirectory(), fileName)
    }

    fun getFileName(filePath: String): String {
        var where = filePath.lastIndexOf('/')
        if (where != -1) {
            val fileName = filePath.substring(where + 1)
            where = fileName.lastIndexOf('.')
            if (where != -1) {
                return fileName.substring(0, where)
            }
            return fileName
        } else {
            where = filePath.lastIndexOf('\\')
            if (where != -1) {
                return filePath.substring(where + 1)
            }
        }
        return filePath
    }

    fun listAudioFiles(directoryFile: File, containsDirectory: Boolean): List<String> {
        val files = ArrayList<String>()
        val pattern = Pattern.compile("\\.(?:mp3|ogg|wav|flac)$", Pattern.CASE_INSENSITIVE)

        val rawFiles = directoryFile.listFiles(FileFilter { file ->
            if (containsDirectory) {
                if (file.isDirectory || file.isFile && pattern.matcher(file.name).find()) {
                    return@FileFilter true
                }
            } else {
                if (file.isFile && pattern.matcher(file.name).find()) {
                    return@FileFilter true
                }
            }

            false
        })
        if (rawFiles != null) {
            val collator = Collator.getInstance(Locale.CHINA)

            Arrays.sort(rawFiles, Comparator<File> { file, t1 ->
                if (containsDirectory) {
                    if (file.isDirectory && t1.isDirectory || file.isFile && t1.isFile) {
                        return@Comparator collator.compare(file.name, t1.name)
                    }
                    if (file.isDirectory && t1.isFile) return@Comparator -1
                    if (file.isFile && t1.isDirectory) return@Comparator 1
                } else {
                    return@Comparator collator.compare(file.name, t1.name)
                }
                0
            })

        }

        for (file in rawFiles!!) {
            files.add(file.name)
        }
        return files
    }
}
