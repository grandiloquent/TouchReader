package euphoria.psycho.ebook;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Pair;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class AnnotationProvider extends SQLiteOpenHelper {

    private static AnnotationProvider sAnnotationProvider;

    private static final String TABLE_NAME = "annotations";
    private static final String FIELD_ID = "_id";
    private static final String FIELD_CONTENT = "content";


    public static AnnotationProvider getInstance(Context context) {
        if (sAnnotationProvider == null) {
            sAnnotationProvider = new AnnotationProvider(context);
        }
        return sAnnotationProvider;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS annotations (_id INTEGER PRIMARY KEY AUTOINCREMENT,content TEXT)");

    }

    public List<Pair<Integer, String>> listAll() {
        List<Pair<Integer, String>> list = new ArrayList<>();

        Cursor cursor = getReadableDatabase().rawQuery("SELECT * FROM " + TABLE_NAME, null);

        while (cursor.moveToNext()) {
            list.add(Pair.create(cursor.getInt(0), cursor.getString(1)));
        }
        cursor.close();
        return list;
    }

    public void insert(String content) {

        ContentValues values = new ContentValues();
        values.put(FIELD_CONTENT, content);
        getWritableDatabase().insert(TABLE_NAME, null, values);

    }

    public void delete(int id) {
        getWritableDatabase().delete(TABLE_NAME, "_id=?", new String[]{Integer.toString(id)});
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public AnnotationProvider(Context context) {
        super(context, new File(new File(Environment.getExternalStorageDirectory(), ".readings"), "annotations.db").getAbsolutePath(),
                null, 1);

    }
}
