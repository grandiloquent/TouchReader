package euphoria.psycho.ebook

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Environment
import java.io.File

class KindleAnnotation(context: Context?) : SQLiteOpenHelper(context, File(Environment.getExternalStorageDirectory(), "annotations.db").absolutePath, null, 5) {
    override fun onCreate(p0: SQLiteDatabase?) {


    }

    fun export(): String {

        // TIME DESC
        val cursor = readableDatabase.rawQuery("select BOOK_TEXT from Annotations ORDER BY BOOKID", arrayOfNulls(0));
        val sb = StringBuffer()
        while (cursor.moveToNext()) {
            sb.append(cursor.getString(0)).append("\r\n\r\n");
        }
        cursor.close();
        return sb.toString()
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}