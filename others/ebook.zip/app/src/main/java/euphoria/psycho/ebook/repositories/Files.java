package euphoria.psycho.ebook.repositories;

import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;

public class Files {
    public static final char AltDirectorySeparatorChar = '/';

    public static String getExternalStorageDirectoryPath(String fileName) {

        return new File(Environment.getExternalStorageDirectory(), fileName).getAbsolutePath();
    }

    public static String changeExtension(String path, String extension) {
        if (path != null) {

            String s = path;
            for (int i = path.length(); --i >= 0; ) {
                char ch = path.charAt(i);
                if (ch == '.') {
                    s = path.substring(0, i);
                    break;
                }
                if (ch == AltDirectorySeparatorChar) break;
            }
            if (extension != null && path.length() != 0) {
                if (extension.length() == 0 || extension.charAt(0) != '.') {
                    s = s + ".";
                }
                s = s + extension;
            }
            return s;
        }
        return null;
    }

    public static void writeStringToFile(String path, String content) throws IOException {

        writeStringToFile(path, content, Charset.forName("UTF8"));
    }

    public static void writeStringToFile(String path, String content, Charset charset) throws IOException {

        FileOutputStream fileOutputStream = new FileOutputStream(path);
        byte[] buffer = content.getBytes(charset);

        fileOutputStream.write(buffer, 0, buffer.length);

        fileOutputStream.flush();
        fileOutputStream.close();
    }
}
