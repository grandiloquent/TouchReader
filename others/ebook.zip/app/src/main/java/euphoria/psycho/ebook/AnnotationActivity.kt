package euphoria.psycho.ebook

import android.app.ListActivity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.util.Pair
import android.view.*
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.TextView
import euphoria.psycho.ebook.repositories.ViewHelper

class AnnotationActivity : ListActivity() {
    private var mAdapter: AnnotationsAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_annotation)

        val listView = listView
        mAdapter = AnnotationsAdapter(AnnotationProvider.getInstance(this).listAll(), this, R.layout.list_item)
        listView.adapter = mAdapter

        registerForContextMenu(listView)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, ViewHelper.ID_EXIST, 0, ViewHelper.ID_EXIST_LABEL)

        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            ViewHelper.ID_EXIST -> finish()
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenu.ContextMenuInfo) {
        menu.add(0, 101, 0, "删除")
        menu.add(0, 102, 0, "复制")

        super.onCreateContextMenu(menu, v, menuInfo)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo


        when (item.itemId) {
            101 -> {
                AnnotationProvider.getInstance(this).delete(mAdapter!!.getItem(info.position)!!.first)
                mAdapter!!.switchData(AnnotationProvider.getInstance(this).listAll())
                return true
            }
            102 -> {
                val clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboardManager.primaryClip = ClipData.newPlainText(null, mAdapter!!.getItem(info.position)!!.second)
                return true
            }
        }
        return super.onContextItemSelected(item)
    }

    private inner class ViewHolder {
        var textView: TextView? = null
    }

    private inner class AnnotationsAdapter internal constructor(private val mPairList: MutableList<Pair<Int, String>>?, private val mContext: Context, private val mLayoutResId: Int) : BaseAdapter() {

        override fun getCount(): Int {
            return mPairList?.size ?: 0
        }

        fun switchData(pairList: List<Pair<Int, String>>) {
            mPairList!!.clear()
            mPairList.addAll(pairList)
            notifyDataSetChanged()
        }

        override fun getItem(i: Int): Pair<Int, String>? {
            return if (mPairList == null) null else mPairList[i]
        }

        override fun getItemId(i: Int): Long {
            return i.toLong()
        }

        override fun getView(i: Int, view: View?, viewGroup: ViewGroup): View {
            var counterview = view
            var viewHolder: ViewHolder

            if (counterview == null) {
                counterview = LayoutInflater.from(mContext).inflate(mLayoutResId, viewGroup, false)
                viewHolder = ViewHolder()
                viewHolder.textView = counterview!!.findViewById<TextView>(R.id.title)

                counterview.tag = viewHolder
            } else {
                viewHolder = counterview.tag as ViewHolder
            }
            viewHolder.textView!!.text = mPairList!![i].second
            return counterview!!
        }
    }
}
