package euphoria.psycho.ebook;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import euphoria.psycho.ebook.repositories.Files;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ArticleProvider {
    private final Context mContext;
    private final DataProvider mDataProvider;
    private static ArticleProvider sArticleProvider;

    public void deleteByTag(String tag) {
        mDataProvider.deleteByTag(tag);
    }

    public String exportDocument(String tag) {
        return mDataProvider.exportDocument(tag);
    }

    public static ArticleProvider getInstance(Context context) {
        if (sArticleProvider == null) {
            sArticleProvider = new ArticleProvider(context);
        }
        return sArticleProvider;
    }

    public void importDocument(File file) {
        try {

            int threshold = 8000;
            FileInputStream in = new FileInputStream(file);

            InputStreamReader reader = new InputStreamReader(in, Charset.forName("utf8"));
            BufferedReader bufferedReader = new BufferedReader(reader);

            StringBuilder sb = new StringBuilder(threshold);
            String l;
            String tag = FileUtils.getFileNameWithoutExtension(file.getName());
            int count = 0;
            while ((l = bufferedReader.readLine()) != null) {
                if (l.trim().length() > 0)
                    sb.append(l).append("\n\n");
                if (sb.length() > threshold) {

                    mDataProvider.insert(tag, sb.toString(), ++count);
                    sb = new StringBuilder(threshold);
                }
            }

            if (sb.length() > 0) {
                mDataProvider.insert(tag, sb.toString(), ++count);
            }
            FileUtils.closeSilently(reader);
            FileUtils.closeSilently(bufferedReader);
            FileUtils.closeSilently(in);
            File dir = new File(Files.getExternalStorageDirectoryPath(".readings"), ".imported");
            dir.mkdirs();
            File targetFile = new File(dir, file.getName());
            if (!targetFile.isFile())
                file.renameTo(targetFile);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void insert(String tag, String value) {
        mDataProvider.insert(tag, value, 1);
    }

    public void insertArticle(String context) {
        mDataProvider.insertArticle(context);
    }

    public void insertArticle(String context, boolean isKindle) {
        mDataProvider.insertArticle(context, isKindle);
    }
    public void  addFromClipboard(String tag,String context){
        mDataProvider.addFromClipboard(tag,context);
    }
    public List<String> listTag() {

        return mDataProvider.listTag();
    }

    public String queryContent(String tag, int count) {

        return mDataProvider.queryContent(tag, count);
    }

    public List<String> queryMatchesContent(String tag, Pattern pattern) {
        return mDataProvider.queryMatchesContent(tag, pattern);
    }

    public String queryMatchesString(String tag, Pattern pattern) {
        return mDataProvider.queryMatchesString(tag, pattern);
    }

    public int[] querySettings(String tag) {

        return mDataProvider.querySettings(tag);
    }

    public void updateSettings(String tag, int count, int scrollY) {
        mDataProvider.updateSettings(tag, count, scrollY);
    }

    public void updateTag(String tag, String newTag) {
        mDataProvider.updateTag(tag, newTag);
    }

    public ArticleProvider(Context mContext) {
        this.mContext = mContext;
        mDataProvider = new DataProvider(mContext);
    }

    private class DataProvider extends SQLiteOpenHelper {


        public void deleteByTag(String tag) {
            //DELETE FROM COMPANY WHERE ID = 7;
            getWritableDatabase().delete("document", "tag=?", new String[]{tag});

        }

        public String exportDocument(String tag) {

            Cursor cursor = getReadableDatabase().rawQuery("SELECT content FROM document WHERE tag = ? ORDER BY count ", new String[]{tag});
            StringBuilder builder = new StringBuilder();
            while (cursor.moveToNext()) {

                // ,count    int i=cursor.getInt(1);
                builder.append(cursor.getString(0)).append("\n\n");
            }

            cursor.close();
            return builder.toString();
        }

        public void insert(String tag, String content, int count) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("tag", tag);
            contentValues.put("content", content);
            contentValues.put("count", count);
            getWritableDatabase().insert("document", null, contentValues);
        }

        public void insertArticle(String context) {

            Cursor cursor = getReadableDatabase().query("document", new String[]{"count"}, "tag=?", new String[]{"Stories From Clipboard"}, null, null, "count DESC");
            int count = 1;
            if (cursor.moveToNext()) {
                count = cursor.getInt(0) + 1;
            }
            cursor.close();
            ContentValues contentValues = new ContentValues();
            contentValues.put("tag", "Stories From Clipboard");
            contentValues.put("count", count);
            contentValues.put("content", context);
            getWritableDatabase().insert("document", null, contentValues);
        }

        public void insertArticle(String context, boolean isKindle) {

            String[] splited = context.split("\n");
            StringBuilder stringBuilder = new StringBuilder();
            Cursor cursor = getReadableDatabase().query("document", new String[]{"count"}, "tag=?", new String[]{"Kindle"}, null, null, "count DESC");
            int count = 1;
            if (cursor.moveToNext()) {
                count = cursor.getInt(0) + 1;
            }
            cursor.close();
            for (int i = 0; i < splited.length; i++) {
                if (stringBuilder.length() < 8000) {
                    stringBuilder.append(splited[i].trim()).append("\n\n");
                } else {

                    ContentValues contentValues = new ContentValues();
                    contentValues.put("tag", "Kindle");
                    contentValues.put("count", count);
                    contentValues.put("content", stringBuilder.toString());
                    getWritableDatabase().insert("document", null, contentValues);
                    count++;
                    stringBuilder=new StringBuilder();
                }
            }
            if(stringBuilder.length()>0){

                ContentValues contentValues = new ContentValues();
                contentValues.put("tag", "Kindle");
                contentValues.put("count", count);
                contentValues.put("content", stringBuilder.toString());
                getWritableDatabase().insert("document", null, contentValues);
            }




        }

        public List<String> listTag() {

            Cursor cursor = getReadableDatabase().rawQuery("SELECT DISTINCT tag FROM document ORDER BY tag", null);

            List<String> list = new ArrayList<>();

            while (cursor.moveToNext()) {
                list.add(cursor.getString(0));
            }
            cursor.close();
            return list;
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS document (tag TEXT ,content TEXT,count INTEGER)");
            sqLiteDatabase.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `idx_tag_count` ON `document` (`tag` ,`count` ASC)");
            sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS settings (tag TEXT ,count INTEGER,scrollY INTEGER)");
            sqLiteDatabase.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `idx_tag` ON `settings` (`tag` )");

        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        }

        public String query(String key) {

            Cursor cursor = getReadableDatabase().rawQuery("select word from dic where key = ?", new String[]{key});

            String result = null;
            if (cursor.moveToNext()) {
                result = cursor.getString(0);
            }
            cursor.close();
            return result;
        }

        public String queryContent(String tag, int count) {
            Cursor cursor = getReadableDatabase().rawQuery("SELECT content FROM document WHERE tag = ? AND count = ?", new String[]{tag, Integer.toString(count)});

            String result = "";

            if (cursor.moveToNext()) {
                result = cursor.getString(0);
            }
            cursor.close();
            return result;
        }

        public List<String> queryMatchesContent(String tag, Pattern pattern) {
            Cursor cursor = getReadableDatabase().rawQuery("SELECT count,content FROM document WHERE tag = ?", new String[]{tag});
            List<String> list = new ArrayList<>();


            while (cursor.moveToNext()) {
                if (pattern.matcher(cursor.getString(1)).find()) {
                    list.add(cursor.getString(0));
                }
            }
            cursor.close();
            return list;
        }

        public String queryMatchesString(String tag, Pattern pattern) {
            Cursor cursor = getReadableDatabase().rawQuery("SELECT count,content FROM document WHERE tag = ?", new String[]{tag});
            StringBuilder stringBuilder = new StringBuilder();

            while (cursor.moveToNext()) {
                Matcher matcher = pattern.matcher(cursor.getString(1));

                if (matcher.find()) {
                    stringBuilder.append(cursor.getString(0)).append("\n");
                    stringBuilder.append(matcher.group()).append("\n\n");
                }
                while (matcher.find()) {
                    stringBuilder.append(matcher.group()).append("\n\n");
                }

            }
            cursor.close();
            return stringBuilder.toString();
        }

        public int[] querySettings(String tag) {
            int[] settings = new int[2];
            Cursor cursor = getReadableDatabase().rawQuery("SELECT count,scrollY FROM settings WHERE tag = ?", new String[]{tag});

            if (cursor.moveToNext()) {
                settings[0] = cursor.getInt(0);
                settings[1] = cursor.getInt(1);
            }
            cursor.close();

            return settings;
        }

        public void updateSettings(String tag, int count, int scrollY) {

            ContentValues initialValues = new ContentValues();
            initialValues.put("tag", tag); // the execution is different if _id is 2
            initialValues.put("count", count);
            initialValues.put("scrollY", scrollY);

            int id = (int) getWritableDatabase().insertWithOnConflict("settings", null, initialValues, SQLiteDatabase.CONFLICT_IGNORE);
            if (id == -1) {
                getWritableDatabase().update("settings", initialValues, "tag=?", new String[]{tag});  // number 1 is the _id here, update to variable for your code
            }
        }

        public void  addFromClipboard(String tag,String context){
            Cursor cursor = getReadableDatabase().query("document", new String[]{"count"}, "tag=?", new String[]{tag}, null, null, "count DESC");
            int count = 1;
            if (cursor.moveToNext()) {
                count = cursor.getInt(0) + 1;
            }
            cursor.close();
            ContentValues contentValues = new ContentValues();
            contentValues.put("tag", tag);
            contentValues.put("count", count);
            contentValues.put("content", context);
            getWritableDatabase().insert("document", null, contentValues);
        }
        public void updateTag(String tag, String newTag) {

            ContentValues initialValues = new ContentValues();
            initialValues.put("tag", newTag); // the execution is different if _id is 2


            getWritableDatabase().update("document", initialValues, "tag=?", new String[]{tag});  // number 1 is the _id here, update to variable for your code
        }

        public DataProvider(Context context) {

            super(context, new File(new File(Environment.getExternalStorageDirectory(), ".readings"), "datas.db").getAbsolutePath(),
                    null, 1);

        }
    }
}
