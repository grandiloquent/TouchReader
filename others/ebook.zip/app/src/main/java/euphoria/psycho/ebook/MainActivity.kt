package euphoria.psycho.ebook

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.style.BackgroundColorSpan
import android.view.*
import android.widget.*
import euphoria.psycho.ebook.repositories.DatabaseCacheManager
import euphoria.psycho.ebook.repositories.PreferManager
import euphoria.psycho.ebook.repositories.ViewHelper
import java.io.File
import java.util.regex.Pattern

class MainActivity : Activity(), ReaderView.SelectListener, Translator.AsyncTaskListener {
    private var mCount = 1
    private var mIsChinese: Boolean = false
    private var mMessageTextView: TextView? = null
    private var mReaderView: ReaderView? = null
    private var mScrollView: ScrollView? = null
    private var mTag: String? = null
    private var mRootLayout: View? = null
    private var mSettingPopupWindow: SettingPopupWindow? = null

    private fun applyReaderViewSetting() {
        val sharedPreferences = AppUtils.getDefaultSharedPreferences()

        val typeface = sharedPreferences.getString("typeface", null)

        if (typeface != null) {
            val file = File(typeface)
            if (file.exists())
                mReaderView!!.typeface = Typeface.createFromFile(file)
        }

        var fontSize = sharedPreferences.getFloat("fontsize", 0f)
        if (fontSize > 0) {
            fontSize = fontSize * resources.displayMetrics.scaledDensity
            mReaderView!!.textSize = fontSize
        }
        val padding = sharedPreferences.getInt("padding", 0)
        if (padding > 0) {
            mReaderView!!.setPadding(padding, padding + 80, padding, padding)

        }
        val mul = sharedPreferences.getFloat("lineSpacingMultiplier", 0f)
        if (mul > 0) {
            mReaderView!!.setLineSpacing(0f, mul)
        }
        val explainFontSize = AppUtils.getDefaultSharedPreferences().getFloat("explainfontsize", 0f)
        if (explainFontSize > 0) {
            mMessageTextView!!.textSize = explainFontSize
        }

    }

    private fun applySettings() {
        val sharedPreferences = AppUtils.getDefaultSharedPreferences()

        val tag = sharedPreferences.getString("tag", null) ?: return
        var count = 1
        var scrollY = 0

        val settings = ArticleProvider.getInstance(this).querySettings(tag)

        if (settings.size > 1) {
            count = settings[0]
            scrollY = settings[1]
        }
        loadContent(tag, count, scrollY)
        mIsChinese = sharedPreferences.getBoolean("is_chinese", true)
        if (mIsChinese)
            Translator.getInstance(this).setListener(this)
        else
            TranslatorMerriam.getInstance(this).setListener(this)
    }

    private fun loadContent(tag: String?, count: Int, scrollY: Int) {
        var count = count
        if (tag != null) {
            mTag = tag
        }
        if (mTag == null) return
        if (count < 1) count = 1
        mCount = count

        mReaderView!!.text = ArticleProvider.getInstance(this).queryContent(mTag, mCount)

        if (scrollY > -1) {
            mScrollView!!.post { mScrollView!!.scrollTo(0, scrollY) }
        }
    }

    private fun prepare() {
        mReaderView = findViewById<ReaderView>(R.id.readerView)
        mMessageTextView = findViewById<TextView>(R.id.message)
        mScrollView = findViewById<ScrollView>(R.id.scrollView)

        mMessageTextView!!.setTextIsSelectable(true)


        mReaderView!!.setSelectListener(this)

        applySettings()
        applyReaderViewSetting()
    }

    private fun search() {
        val editText = EditText(this)

        editText.setText(AppUtils.getDefaultSharedPreferences().getString("pattern", null))
        val builder = AlertDialog.Builder(this)
                .setTitle("在类别中查找")
                .setView(editText)
                .setPositiveButton("确定") { dialogInterface, i ->
                    if (editText.text.toString().trim { it <= ' ' }.length > 0) {
                        dialogInterface.dismiss()

                        val pattern = Pattern.compile(editText.text.toString())
                        PreferManager.instance!!.putString("pattern", editText.text.toString().trim { it <= ' ' })

                        var list: List<String>? = DatabaseCacheManager.initializeInstance(this@MainActivity).getAnchors(editText.text.toString(), mTag!!)

                        if (list == null) {
                            list = ArticleProvider.getInstance(this@MainActivity).queryMatchesContent(mTag, pattern)
                            if (list != null)
                                DatabaseCacheManager.instance!!.insert(editText.text.toString(), mTag!!, list)
                        }
                        val listPopupWindow = ListPopupWindow(this@MainActivity)
                        val arrayAdapter = ArrayAdapter(this@MainActivity, R.layout.list_item, R.id.title, list)
                        listPopupWindow.setAdapter(arrayAdapter)
                        listPopupWindow.isModal = true
                        listPopupWindow.anchorView = findViewById<View>(R.id.layout)
                        val height = resources.displayMetrics.heightPixels
                        val width = resources.displayMetrics.widthPixels
                        listPopupWindow.verticalOffset = height * -1 + 30
                        listPopupWindow.horizontalOffset = 10
                        listPopupWindow.width = width - 20
                        listPopupWindow.height = height - 120

                        listPopupWindow.setOnItemClickListener { adapterView, view, i, l ->
                            mCount = Integer.parseInt(arrayAdapter.getItem(i))
                            mReaderView!!.text = ArticleProvider.getInstance(this@MainActivity).queryContent(mTag, mCount)
                            listPopupWindow.dismiss()
                        }
                        listPopupWindow.show()
                    } else {
                        dialogInterface.dismiss()
                    }
                }
        builder.create().show()
    }

    private fun searchString() {
        val editText = EditText(this)

        editText.setText(AppUtils.getDefaultSharedPreferences().getString("pattern", null))
        val builder = AlertDialog.Builder(this)
                .setTitle("在类别中查找")
                .setView(editText)
                .setPositiveButton("确定") { dialogInterface, i ->
                    if (editText.text.toString().trim { it <= ' ' }.length > 0) {
                        dialogInterface.dismiss()

                        val content = ArticleProvider.getInstance(this@MainActivity).queryContent(mTag!! + " " + editText.text.toString(), 1);
                        if (content.length < 1) {
                            val value = ArticleProvider.getInstance(this@MainActivity).queryMatchesString(mTag!!, Pattern.compile(editText.text.toString()))
                            if (value.length > 0) {
                                ArticleProvider.getInstance(this@MainActivity).insert(mTag!! + " " + editText.text.toString(), value)
                            }
                        }

                    } else {
                        dialogInterface.dismiss()
                    }
                }
        builder.create().show()
    }

    private fun searchInCurrent() {
        val editText = EditText(this)

        editText.setText(AppUtils.getDefaultSharedPreferences().getString("pattern", null))
        val builder = AlertDialog.Builder(this)
                .setTitle("在文档中查找")
                .setView(editText)
                .setPositiveButton("确定") { dialogInterface, i ->
                    if (editText.text.toString().trim { it <= ' ' }.length > 0) {
                        dialogInterface.dismiss()

                        val pattern = Pattern.compile(editText.text.toString())

                        PreferManager.instance!!.putString("pattern", editText.text.toString().trim { it <= ' ' })
                        val value = mReaderView!!.text.toString()


                        val linkifiedText = SpannableStringBuilder(value)

                        val matcher = pattern.matcher(value)
                        var offset = 0
                        while (matcher.find()) {
                            if (offset == 0)
                                offset = matcher.start()
                            val start = matcher.start()
                            val end = matcher.end()
                            val span = BackgroundColorSpan(Color.YELLOW)
                            linkifiedText.setSpan(span, start, end, 0)

                        }
                        mReaderView!!.text = linkifiedText

                        if (offset > 0) {
                            ViewHelper.bringPointIntoView(mReaderView!!, mScrollView!!, offset)
                        }
                    } else {
                        dialogInterface.dismiss()
                    }
                }
        builder.create().show()
    }

    private fun setDecreaseFontSize() {

        var fontsize = PreferManager.instance!!.getFloat("fontsize")

        if (fontsize > 0) {
            fontsize = fontsize - .5f
            PreferManager.instance!!.putFloat("fontsize", fontsize)
            fontsize = fontsize * resources.displayMetrics.scaledDensity
            mReaderView!!.textSize = fontsize
        }
    }

    private fun setIncreaseFontSize() {

        var fontsize = PreferManager.instance!!.getFloat("fontsize")

        if (fontsize > 0) {
            fontsize = fontsize + .5f
            PreferManager.instance!!.putFloat("fontsize", fontsize)
            fontsize = fontsize * resources.displayMetrics.scaledDensity
            mReaderView!!.textSize = fontsize
        }
    }

    private fun setJump() {
        val editText = EditText(this)

        editText.setText(Integer.toString(mCount))
        val builder = AlertDialog.Builder(this)
                .setTitle("退转")
                .setView(editText)
                .setPositiveButton("确定") { dialogInterface, i ->
                    val pattern = Pattern.compile("[0-9\\.]+")
                    val matcher = pattern.matcher(editText.text)
                    if (matcher.find() && mTag != null) {

                        mCount = Integer.parseInt(matcher.group())
                        loadContent(mTag, mCount, 0)
                    }
                    dialogInterface.dismiss()
                }
        builder.create().show()
    }

    private fun initializeView() {
        setContentView(R.layout.activity_main)
        mRootLayout = findViewById<View>(R.id.layout)

    }

    private fun showBottomMenu() {
        if (mSettingPopupWindow == null) {
            mSettingPopupWindow = SettingPopupWindow(this)
            mSettingPopupWindow!!.setListener(object : SettingPopupWindow.Listener {
                override fun switchDictionary() {
                    mIsChinese = !mIsChinese
                    if (mIsChinese)
                        Translator.getInstance(this@MainActivity).setListener(this@MainActivity)
                    else
                        TranslatorMerriam.getInstance(this@MainActivity).setListener(this@MainActivity)
                    PreferManager.instance!!.putBoolean("is_chinese", mIsChinese)
                }

                override fun switchSelectable() {
                    mReaderView!!.switchSelectable()
                }

                override fun increaseFontSize() {
                    setIncreaseFontSize()
                }

                override fun decreaseFontSize() {
                    setDecreaseFontSize()
                }

                override fun openSettings() {
                    val intentSetting = Intent(this@MainActivity, SettingsActivity::class.java)
                    startActivityForResult(intentSetting, SETTING_REQUEST_CODE)
                }

                override fun jump() {
                    setJump()
                }

                override fun openFileBrowser() {
                    val intent = Intent(this@MainActivity, FileExplorerActivity::class.java)
                    startActivity(intent)
                }

                override fun openTableContents() {
                    val intent = Intent(this@MainActivity, DocumentsActivity::class.java)
                    startActivityForResult(intent, DOCUMENT_REQUEST_CODE)
                }

                override fun searchInCurrent() {
                    this@MainActivity.searchInCurrent()
                }

                override fun searchInDocument() {
                    search()
                }

                override fun openAnnotations() {
//                    startActivity(Intent(this@MainActivity, AnnotationActivity::class.java))

                    startService(Intent(this@MainActivity, ClipboardService::class.java))

                }

                override fun searchInDocumentString() {

                    searchString()
                }
            })
            mSettingPopupWindow!!.animationStyle = R.style.pop_window_anim_style
        }
        mSettingPopupWindow!!.showAtLocation(mRootLayout, Gravity.BOTTOM, 0, 0)

        /*

         */
    }

    override fun onPostExecute(value: String) {
        mMessageTextView!!.text = value
    }

    override fun onPreExecute() {

    }

    override fun onError(value: String) {
        mMessageTextView!!.text = null
        //Toast.makeText(this, value, Toast.LENGTH_SHORT).show();
    }

    override fun onSelectionChange(value: String) {

        if (mIsChinese)
            Translator.getInstance(this).addRequestQueue(value.trim { it <= ' ' })
        else
            TranslatorMerriam.getInstance(this).addRequestQueue(value.trim { it <= ' ' })

    }

    override fun onClick() {
        mMessageTextView!!.text = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AppUtils.setContext(this)
        super.onCreate(savedInstanceState)
        initializeView()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.INTERNET), 100)
        }
        prepare()
        PreferManager.initializeInstance(this)
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onPause() {
        if (mTag != null) {
            val editor = AppUtils.getDefaultSharedPreferences().edit()

            editor.putString("tag", mTag).putInt("count", mCount).commit()
            ArticleProvider.getInstance(this).updateSettings(mTag, mCount, mScrollView!!.scrollY)
        }
        super.onPause()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val action = item.itemId
        when (action) {


            R.id.action_forward -> {
                if (mTag == null) return true
                mCount++
                mReaderView!!.text = ArticleProvider.getInstance(this).queryContent(mTag, mCount)
                mScrollView!!.post { mScrollView!!.scrollTo(0, 0) }
            }
            R.id.action_back -> {
                if (mTag == null) return true
                if (mCount == 1) return true
                mCount--
                mReaderView!!.text = ArticleProvider.getInstance(this).queryContent(mTag, mCount)
                mScrollView!!.post { mScrollView!!.scrollTo(0, 0) }
            }


            R.id.action_setting -> showBottomMenu()
        }
        return true
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK && requestCode == DOCUMENT_REQUEST_CODE) {
            val tag = data!!.getStringExtra("tag")
            var count = 1
            var scrollY = 0

            val settings = ArticleProvider.getInstance(this).querySettings(tag)

            if (settings.size > 1) {
                count = settings[0]
                scrollY = settings[1]
            }
            loadContent(tag, count, scrollY)
        } else if (resultCode == Activity.RESULT_OK && requestCode == SETTING_REQUEST_CODE) {
            applyReaderViewSetting()
        }
    }

    companion object {
        private val DOCUMENT_REQUEST_CODE = 1
        private val SETTING_REQUEST_CODE = 2
    }
}
