package euphoria.psycho.notes;

public class Constants {
    public static final int REQUEST_PERIMISSION = 101;
    public static final String DATABASE_FILENAME = "notes.db";
    public static final String EXTRA_ID = "id";
    public static final String EXTRA_TAG = "tag";
    public static final String EXTRA_SEARCH = "search";
}
