package euphoria.psycho.notes;

import java.util.Date;

public class Note {

    public Long ID;
    public String Title;
    public String Content;
    public Date UpdateTime;
    public Date CreateTime;
    public String Tag;
}
