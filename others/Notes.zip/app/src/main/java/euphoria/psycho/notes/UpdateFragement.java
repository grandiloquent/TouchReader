package euphoria.psycho.notes;

public interface UpdateFragement {
    void updateFragement();
}
