package euphoria.psycho.notes;

import android.content.Context;

public class Utils {
    private static Context sContext;

    public static void setContext(Context context) {
        sContext = context;
    }

    public static Context getContext() {
        return sContext;
    }
}
