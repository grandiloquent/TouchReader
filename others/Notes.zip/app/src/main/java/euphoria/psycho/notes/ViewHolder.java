package euphoria.psycho.notes;

import android.widget.TextView;

public class ViewHolder {
    public TextView textView;

}
