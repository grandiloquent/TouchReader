﻿namespace Assistant
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.压缩目录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.压缩子目录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.解压目录下的文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSplitButton2 = new System.Windows.Forms.ToolStripSplitButton();
            this.stringBuilderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.格式化C代码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.格式化CSVJSONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.单行代码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cSSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colordefinitionsscssToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.十二生肖ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.自然数0100ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kotlinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.combinektFilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lotteryButton = new System.Windows.Forms.ToolStripSplitButton();
            this.openDirectoryButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton3 = new System.Windows.Forms.ToolStripSplitButton();
            this.多看WIFI传书文件名ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.排除多看WIFI传书文件名已上传书籍ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.生成wkhtmltopdf命令行ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.合并SafariHTML文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.kotlin = new System.Windows.Forms.ToolStripSplitButton();
            this.提取方法名ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.排序属性ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加const关键字ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.提取声明ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.替换全局声明ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.合并Kotlin文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearButton = new System.Windows.Forms.ToolStripSplitButton();
            this.移除空行目录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zip = new System.Windows.Forms.ToolStripSplitButton();
            this.压缩IntellijAndroid项目ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.orderFunButton = new System.Windows.Forms.ToolStripButton();
            this.orderbyProperty = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.generateFile = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton4 = new System.Windows.Forms.ToolStripSplitButton();
            this.findToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.toolStrip3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSplitButton1,
            this.toolStripSplitButton2,
            this.lotteryButton,
            this.openDirectoryButton,
            this.toolStripSplitButton3});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1151, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "排序函数";
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.压缩目录ToolStripMenuItem,
            this.压缩子目录ToolStripMenuItem,
            this.解压目录下的文件ToolStripMenuItem});
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(48, 22);
            this.toolStripSplitButton1.Text = "压缩";
            // 
            // 压缩目录ToolStripMenuItem
            // 
            this.压缩目录ToolStripMenuItem.Name = "压缩目录ToolStripMenuItem";
            this.压缩目录ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.压缩目录ToolStripMenuItem.Text = "压缩目录";
            this.压缩目录ToolStripMenuItem.Click += new System.EventHandler(this.压缩目录ToolStripMenuItem_Click);
            // 
            // 压缩子目录ToolStripMenuItem
            // 
            this.压缩子目录ToolStripMenuItem.Name = "压缩子目录ToolStripMenuItem";
            this.压缩子目录ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.压缩子目录ToolStripMenuItem.Text = "压缩子目录";
            this.压缩子目录ToolStripMenuItem.Click += new System.EventHandler(this.压缩子目录ToolStripMenuItem_Click);
            // 
            // 解压目录下的文件ToolStripMenuItem
            // 
            this.解压目录下的文件ToolStripMenuItem.Name = "解压目录下的文件ToolStripMenuItem";
            this.解压目录下的文件ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.解压目录下的文件ToolStripMenuItem.Text = "解压目录下的文件";
            this.解压目录下的文件ToolStripMenuItem.Click += new System.EventHandler(this.解压目录下的文件ToolStripMenuItem_Click);
            // 
            // toolStripSplitButton2
            // 
            this.toolStripSplitButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripSplitButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stringBuilderToolStripMenuItem,
            this.toolStripSeparator1,
            this.格式化C代码ToolStripMenuItem,
            this.格式化CSVJSONToolStripMenuItem,
            this.单行代码ToolStripMenuItem,
            this.cSSToolStripMenuItem,
            this.kotlinToolStripMenuItem});
            this.toolStripSplitButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton2.Image")));
            this.toolStripSplitButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton2.Name = "toolStripSplitButton2";
            this.toolStripSplitButton2.Size = new System.Drawing.Size(60, 22);
            this.toolStripSplitButton2.Text = "格式化";
            this.toolStripSplitButton2.ButtonClick += new System.EventHandler(this.toolStripSplitButton2_ButtonClick);
            // 
            // stringBuilderToolStripMenuItem
            // 
            this.stringBuilderToolStripMenuItem.Name = "stringBuilderToolStripMenuItem";
            this.stringBuilderToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.stringBuilderToolStripMenuItem.Text = "StringBuilder";
            this.stringBuilderToolStripMenuItem.Click += new System.EventHandler(this.stringBuilderToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(172, 6);
            // 
            // 格式化C代码ToolStripMenuItem
            // 
            this.格式化C代码ToolStripMenuItem.Name = "格式化C代码ToolStripMenuItem";
            this.格式化C代码ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.格式化C代码ToolStripMenuItem.Text = "格式化C#代码";
            this.格式化C代码ToolStripMenuItem.Click += new System.EventHandler(this.格式化C代码ToolStripMenuItem_Click);
            // 
            // 格式化CSVJSONToolStripMenuItem
            // 
            this.格式化CSVJSONToolStripMenuItem.Name = "格式化CSVJSONToolStripMenuItem";
            this.格式化CSVJSONToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.格式化CSVJSONToolStripMenuItem.Text = "格式化CSV(JSON)";
            this.格式化CSVJSONToolStripMenuItem.Click += new System.EventHandler(this.格式化CSVJSONToolStripMenuItem_Click);
            // 
            // 单行代码ToolStripMenuItem
            // 
            this.单行代码ToolStripMenuItem.Name = "单行代码ToolStripMenuItem";
            this.单行代码ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.单行代码ToolStripMenuItem.Text = "单行(代码)";
            this.单行代码ToolStripMenuItem.Click += new System.EventHandler(this.单行代码ToolStripMenuItem_Click);
            // 
            // cSSToolStripMenuItem
            // 
            this.cSSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.colordefinitionsscssToolStripMenuItem,
            this.十二生肖ToolStripMenuItem,
            this.自然数0100ToolStripMenuItem});
            this.cSSToolStripMenuItem.Name = "cSSToolStripMenuItem";
            this.cSSToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.cSSToolStripMenuItem.Text = "数组";
            // 
            // colordefinitionsscssToolStripMenuItem
            // 
            this.colordefinitionsscssToolStripMenuItem.Name = "colordefinitionsscssToolStripMenuItem";
            this.colordefinitionsscssToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.colordefinitionsscssToolStripMenuItem.Text = "_color-definitions.scss";
            this.colordefinitionsscssToolStripMenuItem.Click += new System.EventHandler(this.colordefinitionsscssToolStripMenuItem_Click);
            // 
            // 十二生肖ToolStripMenuItem
            // 
            this.十二生肖ToolStripMenuItem.Name = "十二生肖ToolStripMenuItem";
            this.十二生肖ToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.十二生肖ToolStripMenuItem.Text = "十二生肖";
            this.十二生肖ToolStripMenuItem.Click += new System.EventHandler(this.十二生肖ToolStripMenuItem_Click);
            // 
            // 自然数0100ToolStripMenuItem
            // 
            this.自然数0100ToolStripMenuItem.Name = "自然数0100ToolStripMenuItem";
            this.自然数0100ToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.自然数0100ToolStripMenuItem.Text = "自然数(0-100)";
            this.自然数0100ToolStripMenuItem.Click += new System.EventHandler(this.自然数0100ToolStripMenuItem_Click);
            // 
            // kotlinToolStripMenuItem
            // 
            this.kotlinToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.combinektFilesToolStripMenuItem});
            this.kotlinToolStripMenuItem.Name = "kotlinToolStripMenuItem";
            this.kotlinToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.kotlinToolStripMenuItem.Text = "Kotlin";
            // 
            // combinektFilesToolStripMenuItem
            // 
            this.combinektFilesToolStripMenuItem.Name = "combinektFilesToolStripMenuItem";
            this.combinektFilesToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.combinektFilesToolStripMenuItem.Text = "Combine .kt Files";
            this.combinektFilesToolStripMenuItem.Click += new System.EventHandler(this.combinektFilesToolStripMenuItem_Click);
            // 
            // lotteryButton
            // 
            this.lotteryButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lotteryButton.Image = ((System.Drawing.Image)(resources.GetObject("lotteryButton.Image")));
            this.lotteryButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.lotteryButton.Name = "lotteryButton";
            this.lotteryButton.Size = new System.Drawing.Size(48, 22);
            this.lotteryButton.Text = "彩票";
            this.lotteryButton.ButtonClick += new System.EventHandler(this.lotteryButton_ButtonClick);
            // 
            // openDirectoryButton
            // 
            this.openDirectoryButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.openDirectoryButton.Image = ((System.Drawing.Image)(resources.GetObject("openDirectoryButton.Image")));
            this.openDirectoryButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openDirectoryButton.Name = "openDirectoryButton";
            this.openDirectoryButton.Size = new System.Drawing.Size(36, 22);
            this.openDirectoryButton.Text = "程序";
            this.openDirectoryButton.Click += new System.EventHandler(this.openDirectoryButton_Click);
            // 
            // toolStripSplitButton3
            // 
            this.toolStripSplitButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.多看WIFI传书文件名ToolStripMenuItem,
            this.排除多看WIFI传书文件名已上传书籍ToolStripMenuItem,
            this.生成wkhtmltopdf命令行ToolStripMenuItem,
            this.合并SafariHTML文件ToolStripMenuItem});
            this.toolStripSplitButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton3.Image")));
            this.toolStripSplitButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton3.Name = "toolStripSplitButton3";
            this.toolStripSplitButton3.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButton3.Text = "toolStripSplitButton3";
            // 
            // 多看WIFI传书文件名ToolStripMenuItem
            // 
            this.多看WIFI传书文件名ToolStripMenuItem.Name = "多看WIFI传书文件名ToolStripMenuItem";
            this.多看WIFI传书文件名ToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.多看WIFI传书文件名ToolStripMenuItem.Text = "多看(WIFI传书文件名)";
            this.多看WIFI传书文件名ToolStripMenuItem.Click += new System.EventHandler(this.多看WIFI传书文件名ToolStripMenuItem_Click);
            // 
            // 排除多看WIFI传书文件名已上传书籍ToolStripMenuItem
            // 
            this.排除多看WIFI传书文件名已上传书籍ToolStripMenuItem.Name = "排除多看WIFI传书文件名已上传书籍ToolStripMenuItem";
            this.排除多看WIFI传书文件名已上传书籍ToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.排除多看WIFI传书文件名已上传书籍ToolStripMenuItem.Text = "排除多看(WIFI传书文件名)已上传书籍";
            this.排除多看WIFI传书文件名已上传书籍ToolStripMenuItem.Click += new System.EventHandler(this.排除多看WIFI传书文件名已上传书籍ToolStripMenuItem_Click);
            // 
            // 生成wkhtmltopdf命令行ToolStripMenuItem
            // 
            this.生成wkhtmltopdf命令行ToolStripMenuItem.Name = "生成wkhtmltopdf命令行ToolStripMenuItem";
            this.生成wkhtmltopdf命令行ToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.生成wkhtmltopdf命令行ToolStripMenuItem.Text = "生成wkhtmltopdf命令行";
            this.生成wkhtmltopdf命令行ToolStripMenuItem.Click += new System.EventHandler(this.生成wkhtmltopdf命令行ToolStripMenuItem_Click);
            // 
            // 合并SafariHTML文件ToolStripMenuItem
            // 
            this.合并SafariHTML文件ToolStripMenuItem.Name = "合并SafariHTML文件ToolStripMenuItem";
            this.合并SafariHTML文件ToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.合并SafariHTML文件ToolStripMenuItem.Text = "合并Safari HTML文件";
            this.合并SafariHTML文件ToolStripMenuItem.Click += new System.EventHandler(this.合并SafariHTML文件ToolStripMenuItem_Click);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.kotlin,
            this.clearButton,
            this.zip,
            this.toolStripButton2});
            this.toolStrip2.Location = new System.Drawing.Point(0, 25);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(1151, 25);
            this.toolStrip2.TabIndex = 1;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(47, 22);
            this.toolStripButton1.Text = "Order";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // kotlin
            // 
            this.kotlin.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.kotlin.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.提取方法名ToolStripMenuItem,
            this.排序属性ToolStripMenuItem,
            this.添加const关键字ToolStripMenuItem,
            this.提取声明ToolStripMenuItem,
            this.替换全局声明ToolStripMenuItem,
            this.合并Kotlin文件ToolStripMenuItem});
            this.kotlin.Image = ((System.Drawing.Image)(resources.GetObject("kotlin.Image")));
            this.kotlin.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.kotlin.Name = "kotlin";
            this.kotlin.Size = new System.Drawing.Size(57, 22);
            this.kotlin.Text = "Kotlin";
            this.kotlin.ButtonClick += new System.EventHandler(this.kotlin_Click);
            // 
            // 提取方法名ToolStripMenuItem
            // 
            this.提取方法名ToolStripMenuItem.Name = "提取方法名ToolStripMenuItem";
            this.提取方法名ToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.提取方法名ToolStripMenuItem.Text = "提取方法名";
            this.提取方法名ToolStripMenuItem.Click += new System.EventHandler(this.提取方法名ToolStripMenuItem_Click);
            // 
            // 排序属性ToolStripMenuItem
            // 
            this.排序属性ToolStripMenuItem.Name = "排序属性ToolStripMenuItem";
            this.排序属性ToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.排序属性ToolStripMenuItem.Text = "排序属性";
            this.排序属性ToolStripMenuItem.Click += new System.EventHandler(this.排序属性ToolStripMenuItem_Click);
            // 
            // 添加const关键字ToolStripMenuItem
            // 
            this.添加const关键字ToolStripMenuItem.Name = "添加const关键字ToolStripMenuItem";
            this.添加const关键字ToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.添加const关键字ToolStripMenuItem.Text = "添加const关键字";
            this.添加const关键字ToolStripMenuItem.Click += new System.EventHandler(this.添加const关键字ToolStripMenuItem_Click);
            // 
            // 提取声明ToolStripMenuItem
            // 
            this.提取声明ToolStripMenuItem.Name = "提取声明ToolStripMenuItem";
            this.提取声明ToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.提取声明ToolStripMenuItem.Text = "提取声明";
            this.提取声明ToolStripMenuItem.Click += new System.EventHandler(this.提取声明ToolStripMenuItem_Click);
            // 
            // 替换全局声明ToolStripMenuItem
            // 
            this.替换全局声明ToolStripMenuItem.Name = "替换全局声明ToolStripMenuItem";
            this.替换全局声明ToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.替换全局声明ToolStripMenuItem.Text = "替换全局声明";
            this.替换全局声明ToolStripMenuItem.Click += new System.EventHandler(this.替换全局声明ToolStripMenuItem_Click);
            // 
            // 合并Kotlin文件ToolStripMenuItem
            // 
            this.合并Kotlin文件ToolStripMenuItem.Name = "合并Kotlin文件ToolStripMenuItem";
            this.合并Kotlin文件ToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.合并Kotlin文件ToolStripMenuItem.Text = "合并Kotlin文件";
            this.合并Kotlin文件ToolStripMenuItem.Click += new System.EventHandler(this.合并Kotlin文件ToolStripMenuItem_Click);
            // 
            // clearButton
            // 
            this.clearButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.clearButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.移除空行目录ToolStripMenuItem});
            this.clearButton.Image = ((System.Drawing.Image)(resources.GetObject("clearButton.Image")));
            this.clearButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(54, 22);
            this.clearButton.Text = "Clear";
            this.clearButton.ButtonClick += new System.EventHandler(this.clearButton_Click);
            // 
            // 移除空行目录ToolStripMenuItem
            // 
            this.移除空行目录ToolStripMenuItem.Name = "移除空行目录ToolStripMenuItem";
            this.移除空行目录ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.移除空行目录ToolStripMenuItem.Text = "移除空行（目录）";
            this.移除空行目录ToolStripMenuItem.Click += new System.EventHandler(this.移除空行目录ToolStripMenuItem_Click);
            // 
            // zip
            // 
            this.zip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.zip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.压缩IntellijAndroid项目ToolStripMenuItem});
            this.zip.Image = ((System.Drawing.Image)(resources.GetObject("zip.Image")));
            this.zip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.zip.Name = "zip";
            this.zip.Size = new System.Drawing.Size(42, 22);
            this.zip.Text = "Zip";
            // 
            // 压缩IntellijAndroid项目ToolStripMenuItem
            // 
            this.压缩IntellijAndroid项目ToolStripMenuItem.Name = "压缩IntellijAndroid项目ToolStripMenuItem";
            this.压缩IntellijAndroid项目ToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.压缩IntellijAndroid项目ToolStripMenuItem.Text = "压缩Intellij Android项目";
            this.压缩IntellijAndroid项目ToolStripMenuItem.Click += new System.EventHandler(this.压缩IntellijAndroid项目ToolStripMenuItem_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStrip3
            // 
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.orderFunButton,
            this.orderbyProperty,
            this.toolStripSeparator2,
            this.generateFile,
            this.toolStripButton3,
            this.toolStripSplitButton4});
            this.toolStrip3.Location = new System.Drawing.Point(0, 50);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(1151, 25);
            this.toolStrip3.TabIndex = 3;
            this.toolStrip3.Text = "toolStrip3";
            // 
            // orderFunButton
            // 
            this.orderFunButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.orderFunButton.Image = ((System.Drawing.Image)(resources.GetObject("orderFunButton.Image")));
            this.orderFunButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.orderFunButton.Name = "orderFunButton";
            this.orderFunButton.Size = new System.Drawing.Size(60, 22);
            this.orderFunButton.Text = "排序函数";
            this.orderFunButton.Click += new System.EventHandler(this.orderFunButton_Click);
            // 
            // orderbyProperty
            // 
            this.orderbyProperty.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.orderbyProperty.Image = ((System.Drawing.Image)(resources.GetObject("orderbyProperty.Image")));
            this.orderbyProperty.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.orderbyProperty.Name = "orderbyProperty";
            this.orderbyProperty.Size = new System.Drawing.Size(60, 22);
            this.orderbyProperty.Text = "排序属性";
            this.orderbyProperty.Click += new System.EventHandler(this.orderbyProperty_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // generateFile
            // 
            this.generateFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.generateFile.Image = ((System.Drawing.Image)(resources.GetObject("generateFile.Image")));
            this.generateFile.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.generateFile.Name = "generateFile";
            this.generateFile.Size = new System.Drawing.Size(60, 22);
            this.generateFile.Text = "生成文件";
            this.generateFile.Click += new System.EventHandler(this.generateFile_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripSplitButton4
            // 
            this.toolStripSplitButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.findToolStripMenuItem});
            this.toolStripSplitButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton4.Image")));
            this.toolStripSplitButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton4.Name = "toolStripSplitButton4";
            this.toolStripSplitButton4.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButton4.Text = "toolStripSplitButton4";
            // 
            // findToolStripMenuItem
            // 
            this.findToolStripMenuItem.Name = "findToolStripMenuItem";
            this.findToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.findToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.findToolStripMenuItem.Text = "Find";
            this.findToolStripMenuItem.Click += new System.EventHandler(this.findToolStripMenuItem_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 75);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.listBox1);
            this.splitContainer1.Panel1.Controls.Add(this.comboBox3);
            this.splitContainer1.Panel1.Controls.Add(this.comboBox2);
            this.splitContainer1.Panel1.Controls.Add(this.comboBox1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.textBox);
            this.splitContainer1.Size = new System.Drawing.Size(1151, 484);
            this.splitContainer1.SplitterDistance = 383;
            this.splitContainer1.TabIndex = 4;
            // 
            // listBox1
            // 
            this.listBox1.ContextMenuStrip = this.contextMenuStrip1;
            this.listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(0, 60);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(383, 424);
            this.listBox1.TabIndex = 1;
            this.listBox1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox1_MouseDoubleClick);
            // 
            // comboBox3
            // 
            this.comboBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(0, 40);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(383, 20);
            this.comboBox3.TabIndex = 3;
            this.comboBox3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.comboBox3_KeyDown);
            // 
            // comboBox2
            // 
            this.comboBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(0, 20);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(383, 20);
            this.comboBox2.TabIndex = 2;
            this.comboBox2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.comboBox2_KeyDown);
            // 
            // comboBox1
            // 
            this.comboBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(0, 0);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(383, 20);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.comboBox1_KeyDown);
            // 
            // textBox
            // 
            this.textBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox.Location = new System.Drawing.Point(0, 0);
            this.textBox.MaxLength = 3276700;
            this.textBox.Multiline = true;
            this.textBox.Name = "textBox";
            this.textBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox.Size = new System.Drawing.Size(764, 484);
            this.textBox.TabIndex = 0;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openDirectoryToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(181, 48);
            // 
            // openDirectoryToolStripMenuItem
            // 
            this.openDirectoryToolStripMenuItem.Name = "openDirectoryToolStripMenuItem";
            this.openDirectoryToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.openDirectoryToolStripMenuItem.Text = "Open Directory";
            this.openDirectoryToolStripMenuItem.Click += new System.EventHandler(this.openDirectoryToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1151, 559);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip3);
            this.Controls.Add(this.toolStrip2);
            this.Controls.Add(this.toolStrip1);
            this.Name = "Form1";
            this.Text = "Assistant";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem 压缩目录ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton2;
        private System.Windows.Forms.ToolStripMenuItem stringBuilderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 压缩子目录ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton lotteryButton;
        private System.Windows.Forms.ToolStripButton openDirectoryButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 格式化C代码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton3;
        private System.Windows.Forms.ToolStripMenuItem 多看WIFI传书文件名ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 排除多看WIFI传书文件名已上传书籍ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 解压目录下的文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 格式化CSVJSONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 单行代码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cSSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colordefinitionsscssToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 十二生肖ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 自然数0100ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 生成wkhtmltopdf命令行ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kotlinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem combinektFilesToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripMenuItem 合并SafariHTML文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton kotlin;
        private System.Windows.Forms.ToolStripMenuItem 提取方法名ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton clearButton;
        private System.Windows.Forms.ToolStripMenuItem 移除空行目录ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton zip;
        private System.Windows.Forms.ToolStripMenuItem 压缩IntellijAndroid项目ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripMenuItem 排序属性ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加const关键字ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 提取声明ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 替换全局声明ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 合并Kotlin文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.ToolStripButton orderFunButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton generateFile;
        private System.Windows.Forms.ToolStripButton orderbyProperty;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton4;
        private System.Windows.Forms.ToolStripMenuItem findToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem openDirectoryToolStripMenuItem;
    }
}

