package euphoria.psycho.notepad;

import android.widget.TextView;

public class ViewHolder {
    public TextView textView;

}
