"# TouchReader" 

- [x] Convert `.epub` or `.mobi` to plain text file.
- [x] Chinese-English,English-English,English-Chninese Online Dictionary
- [x] Translate the word on where touched
