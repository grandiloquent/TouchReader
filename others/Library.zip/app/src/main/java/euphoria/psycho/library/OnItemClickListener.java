package euphoria.psycho.library;

public interface OnItemClickListener {
    void onItemClick(String value);
}